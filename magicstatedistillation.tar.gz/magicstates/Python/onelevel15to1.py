from magic_state_factory import MagicStateFactory
from scipy import optimize
import mpmath

from definitions import (
    z,
    one,
    projx,
    apply_rot,
    kron,
    trace,
    plog,
    storage_x_5,
    storage_z_5,
    init5qubit,
    ideal15to1,
)

# [0.49200202054217884, 0.1929650058775658, 0.01888532477947073, 0.0018217390369579395, 0.0009902939657153967, 0.000986248147671566, 0.0009036170886854912, 0.000913603601621903, 0.0010384837967844964, 0.0010526496991814637] # d=5
# [0.5029021558872305, 0.21259546763490672, 0.011427760229974802, 0.00045602084901075874, 0.00020010780829569257, 0.00021403239901133055, 0.00017559630586651295, 0.00018236457331391695, 0.0002074108537986865, 0.00022126388238458586] # d = 7
# [0.4934876989869754, 0.29462832338578404, 0.0006851308418014697, 3e-07, 1e-07, 1e-07, 0.0, 0.0, 0.0, 1e-07] # d=17

readout_data = {
    5: {70: 0.49200202054217884, 140: 0.1929650058775658, 210: 0.01888532477947073, 280: 0.0018217390369579395, 350: 0.0009902939657153967, 420: 0.000986248147671566, 490: 0.0009036170886854912, 560: 0.000913603601621903, 630: 0.0010384837967844964, 700: 0.0010526496991814637},
    7: {70: 0.5029021558872305, 140: 0.21259546763490672, 210: 0.011427760229974802, 280: 0.00045602084901075874, 350: 0.00020010780829569257, 420: 0.00021403239901133055, 490: 0.00017559630586651295, 560: 0.00018236457331391695, 630: 0.0002074108537986865, 700: 0.00022126388238458586},
    11: {dur: ler for dur, ler in zip([70, 140, 210, 280, 350, 420, 490, 560, 630, 700], [0.5047545618093036, 0.2492002020542179, 0.004113345521023766, 2.89e-05, 6.1e-06, 9.2e-06, 6.7e-06, 6.4e-06, 7.1e-06, 8.5e-06])},
    13: {dur: ler for dur, ler in zip([70, 140, 210, 280, 350, 420, 490, 560, 630, 700], [0.5170916983179599, 0.26149183364202727, 0.002318715061806157, 6.963538815371771e-06, 1.18e-06, 1.45e-06, 1.13e-06, 1.15e-06, 1.45e-06, 1.66e-06])},
    17: {dur: ler for dur, ler in zip([70, 140, 210, 280, 350, 420, 490, 560, 630, 700], [0.506857855361596, 0.27996448653447764, 0.0007291021107506106, 3.4e-07, 3e-08, 9e-08, 2e-08, 7e-08, 5e-08, 4e-08])},
    23: {dur: ler for dur, ler in zip([70, 140, 210, 280, 350, 420, 490, 560, 630, 700], [0.5148514851485149, 0.3252858958068615, 0.00013900665841893827, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])}
}

def one_level_15to1_state(
    pphys: float | mpmath.mpf, dx: int, dz: int, dm: int, rerr: float, rdur: float
) -> mpmath.matrix:
    """
    Generates the output-state density matrix of the 15-to-1 protocol

    `pphys`: The physical error rate

    `dx`, `dz`, `dm`: distance for x, z, and measurement errors respectively
    `rerr`: readout error rate
    `rdur`: readout duration
    """

    pphys = mpmath.mpf(pphys)

    # Introduce shorthand notation for logical error rate with distances dx/dz/dm
    data = readout_data.get(dx, {})
    datazm = readout_data.get(dz, {})
    px = data.get(rdur) / dx if data[rdur] >= 1e-8 else plog(pphys, dx)
    pz = datazm.get(rdur) / dz if datazm[rdur] >= 1e-8 else plog(pphys, dz)
    pm = datazm.get(rdur) / dm if datazm[rdur] >= 1e-8 else plog(pphys, dm)

    # Step 1 of 15-to-1 protocol applying rotations 1-3 and 5
    out = apply_rot(
        init5qubit,
        [one, z, one, one, one],
        pphys / 3 + 0.5 * (dm / dz) * pz * dm,
        pphys / 3 + 0.5 * dz * pm,
        pphys / 3,
    )

    out = apply_rot(
        out,
        [one, one, z, one, one],
        pphys / 3 + 0.5 * (dm / dz) * pz * dm,
        pphys / 3 + 0.5 * dz * pm,
        pphys / 3,
    )

    out = apply_rot(
        out,
        [one, one, one, z, one],
        pphys / 3 + 0.5 * (dm / dz) * pz * dm,
        pphys / 3 + 0.5 * dz * pm,
        pphys / 3,
    )

    out = apply_rot(
        out,
        [one, z, z, z, one],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (3 * dz) * dx / dm * pm,
        pphys / 3,
    )

    # Apply storage errors for dm code cycles

    out = storage_x_5(
        out,
        0,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0,
    )

    out = storage_z_5(
        out,
        0,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0,
    )

    # Step 2: apply rotations 6-7
    # Last operation: apply additional storage errors due to multi-patch measurements

    out = apply_rot(
        out,
        [z, z, z, one, one],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (dx + 2 * dz) * dx / dm * pm,
        pphys / 3,
    )

    out = apply_rot(
        out,
        [z, z, one, z, one],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (dx + 3 * dz) * dx / dm * pm,
        pphys / 3,
    )
    out = storage_z_5(
        out, 0.5 * ((dx + 2 * dz) + (dx + 3 * dz)) / dx * px * dm, 0, 0, 0, 0
    )

    # Apply storage errors for dm code cycles
    out = storage_x_5(
        out,
        0.5 * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0,
    )
    out = storage_z_5(
        out,
        0.5 * px * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0,
    )

    # Step 3: apply rotation 4 and 8-9
    out = apply_rot(
        out,
        [z, one, z, z, one],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (dx + 3 * dz) * dx / dm * pm,
        pphys / 3,
    )
    out = apply_rot(
        out,
        [z, one, one, z, z],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (dx + 4 * dz) * dx / dm * pm,
        pphys / 3,
    )
    out = apply_rot(
        out,
        [one, one, one, one, z],
        pphys / 3 + 0.5 * (dm / dz) * pz * dm,
        pphys / 3 + 0.5 * dz * pm,
        pphys / 3,
    )
    out = storage_z_5(
        out, 0.5 * ((dx + 3 * dz) + (dx + 4 * dz)) / dx * px * dm, 0, 0, 0, 0
    )

    # Apply storage errors for dm code cycles
    out = storage_x_5(
        out,
        0.5 * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
    )
    out = storage_z_5(
        out,
        0.5 * px * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
    )

    # Step 4: apply rotations 10-11
    out = apply_rot(
        out,
        [z, z, one, one, z],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (dx + 4 * dz) * dx / dm * pm,
        pphys / 3,
    )
    out = apply_rot(
        out,
        [z, one, z, one, z],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (dx + 4 * dz) * dx / dm * pm,
        pphys / 3,
    )
    out = storage_z_5(
        out, 0.5 * ((dx + 4 * dz) + (dx + 4 * dz)) / dx * px * dm, 0, 0, 0, 0
    )

    # Apply storage errors for dm code cycles
    out = storage_x_5(
        out,
        0.5 * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
    )
    out = storage_z_5(
        out,
        0.5 * px * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
    )

    # Step 5: apply rotations 12-13
    out = apply_rot(
        out,
        [z, z, z, z, z],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (dx + 4 * dz) * dx / dm * pm,
        pphys / 3,
    )
    out = apply_rot(
        out,
        [one, one, z, z, z],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (3 * dz) * dx / dm * pm,
        pphys / 3,
    )
    out = storage_z_5(out, 0.5 * (dx + 4 * dz) / dx * px * dm, 0, 0, 0, 0)

    # Apply storage errors for dm code cycles
    # Qubit 1 is consumed as an output state: additional storage errors for dx code cycles
    out = storage_x_5(
        out,
        0.5 * px * (dm + 2 * dx),
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
    )
    out = storage_z_5(
        out,
        0.5 * px * (dm + 2 * dx),
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
    )

    # Step 6: apply rotation 14-15
    out = apply_rot(
        out,
        [one, z, one, z, z],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (4 * dz) * dx / dm * pm,
        pphys / 3,
    )
    out = apply_rot(
        out,
        [one, z, z, one, z],
        pphys / 3 + 0.5 * pm * dm,
        pphys / 3 + 0.5 * pm * dm + 0.5 * (4 * dz) * dx / dm * pm,
        pphys / 3,
    )

    # Apply storage errors for dm code cycles
    out = storage_x_5(
        out,
        0,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
        0.5 * (dz / dx) * px * dm,
    )
    out = storage_z_5(
        out,
        0,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
        0.5 * (dx / dz) * pz * dm,
    )

    return out


def cost_of_one_level_15to1(
    pphys: float | mpmath.mpf, dx: int, dz: int, dm: int,
    rerr: float, rdur: float
) -> MagicStateFactory:
    """
    Calculates the output error and cost of the 15-to-1 protocol with a physical error rate `pphys` and distances `dx`, `dz` and `dm`
    """

    pphys = mpmath.mpf(pphys)

    # Generate output state of 15-to-1 protocol
    out = one_level_15to1_state(pphys, dx, dz, dm, rerr, rdur)

    # Compute failure probability as the probability to measure qubits 2-5 in the |+> state
    pfail = (1 - trace(kron(one, projx, projx, projx, projx) * out)).real

    # Compute the density matrix of the post-selected output state, i.e., after projecting qubits 2-5 into |+>
    outpostsel = (
        (1 / (1 - pfail))
        * kron(one, projx, projx, projx, projx)
        * out
        * kron(one, projx, projx, projx, projx).transpose_conj()
    )

    # Compute output error from the infidelity between the post-selected state and the ideal output state
    pout = (1 - trace(outpostsel * ideal15to1)).real

    # Full-distance computation: determine full distance required for a 100-qubit / 10000-qubit computation
    def logerr1(d):
        return float((231 / pout) * d * plog(pphys, d) - 0.01)

    def logerr2(d):
        return float((20284 / pout) * d * plog(pphys, d) - 0.01)

    reqdist1 = int(2 * round(optimize.root(logerr1, 3, method="hybr").x[0] / 2) + 1)
    reqdist2 = int(2 * round(optimize.root(logerr2, 3, method="hybr").x[0] / 2) + 1)

    return MagicStateFactory(
        name=f"15-to-1 with pphys={float(pphys)}, dx={dx}, dz={dz}, dm={dm}, rerr={rerr}, rdur={rdur}",
        distilled_magic_state_error_rate=float(pout),
        qubits=2 * ((dx + 4 * dz) * 3 * dx + 2 * dm),
        distillation_time_in_cycles=float(6 * dm / (1 - pfail)),
        n_t_gates_produced_per_distillation=1,
        postselection_rate=float(1 - pfail),
    )

if __name__ == "__main__":
    # Example usage
    durs = [70, 140, 210, 280, 350, 420, 490, 560, 630, 700]
    fidelities = {
        70: 0.65,
        140: 0.88,
        210: 0.96,
        280: 0.986,
        350: 0.99,
        420: 0.99,
        490: 0.991,
        560: 0.991,
        630: 0.991,
        700: 0.991
    }
    results = {}
    factory = cost_of_one_level_15to1(pphys=1e-3, dx=7, dz=7, dm=7, rerr=0.01, rdur=280)
    print(factory)